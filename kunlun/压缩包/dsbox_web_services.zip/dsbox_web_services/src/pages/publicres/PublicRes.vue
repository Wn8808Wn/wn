<template>
  <div>
    公共资源
  </div>
</template>

<script>
export default {
  name: 'publicres',
  data () {
    return {

    }
  },
  components: {

  }
}
</script>

<style lang="less" scoped>
</style>
