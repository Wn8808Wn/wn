<template>
  <div>

  </div>
</template>

<script>
export default {
  name: 'back',
  data () {
    this.$router.replace({
      path: '/privatedoc',
      name: 'privatedoc'
    })
    return {

    }
  }
}
</script>

<style lang="less" scoped>
</style>
