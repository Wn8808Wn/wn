<template>
  <div>
    回收站
  </div>
</template>

<script>
export default {
  name: 'dustbin',
  data () {
    return {

    }
  },
  components: {

  }
}
</script>

<style lang="less" scoped>
</style>
