<template>
  <div>
    我的收藏
  </div>
</template>

<script>
export default {
  name: 'mycollection',
  data () {
    return {

    }
  },
  components: {

  }
}
</script>

<style lang="less" scoped>
</style>
