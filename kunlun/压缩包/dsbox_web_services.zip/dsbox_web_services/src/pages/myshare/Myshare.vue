<template>
  <div>
    我的分享
  </div>
</template>

<script>
export default {
  name: 'myshare',
  data () {
    return {

    }
  },
  components: {

  }
}
</script>

<style lang="less" scoped>
</style>
